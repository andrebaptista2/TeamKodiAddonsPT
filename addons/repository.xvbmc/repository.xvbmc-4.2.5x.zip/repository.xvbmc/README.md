# REPOsitory.XvBMC
 
**NOTE:** XvBMC Nederland (xbmc nl) wij zijn géén helpdesk van/voor boxverkopers
 
  
   
### XvBMC_Nederland: 
* https://bit.ly/XvBMC-NL (shutdown)
* https://www.fb.com/groups/XvBMCnederland/ (shutdown)
 
### OFFLINE / AFGESLOTEN / SHUTDOWN / DOWN / QUIT / THE END / GESCHLOSSEN / FERMÉ
 
----------
 
*With kind regards,*
 
*Team X(v)BMC Nederland*
 
----------
 
(c) [XvBMC Nederland](https://bit.ly/AddonBlacklist) (r)