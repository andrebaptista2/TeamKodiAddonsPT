import xbmcaddon

MainBase = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL21hY2tsYW5kcm8vZnJlZTRhbGwvbWFzdGVyL2ZpcnN0'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.m.team')