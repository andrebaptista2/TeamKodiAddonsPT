import xbmcaddon

MainBase = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3NsYmZvcmV2ZXJzbGIvbGlrZXRoaXMvbWFzdGVyL29uZQ=='.decode('base64')
addon = xbmcaddon.Addon('plugin.video.m.team')