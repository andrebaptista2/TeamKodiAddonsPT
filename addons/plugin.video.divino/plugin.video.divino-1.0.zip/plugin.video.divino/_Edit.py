import xbmcaddon

MainBase = 'https://pastebin.com/raw/8q9B7f4V'
addon = xbmcaddon.Addon('plugin.video.divino')